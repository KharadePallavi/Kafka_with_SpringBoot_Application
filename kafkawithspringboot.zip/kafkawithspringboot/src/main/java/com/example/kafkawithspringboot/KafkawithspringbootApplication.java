package com.example.kafkawithspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkawithspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkawithspringbootApplication.class, args);
	}

}
