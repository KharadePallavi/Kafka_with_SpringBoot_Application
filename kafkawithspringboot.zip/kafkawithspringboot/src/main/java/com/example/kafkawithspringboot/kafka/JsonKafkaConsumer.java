package com.example.kafkawithspringboot.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.kafkawithspringboot.dao.BookJsonRepository;
import com.example.kafkawithspringboot.model.BookJson;

@Service
public class JsonKafkaConsumer {

	
	@Autowired
	private KafkaTemplate< String, BookJson> kafkaTemplate;
	
	@Autowired
	private BookJsonRepository bookJsonRepository;
	
	@KafkaListener(topics="javaguides_json", groupId = "myGroup" )
	public void consume(BookJson book) {
	bookJsonRepository.save(book);
	System.out.println("Book record="+book.toString());
	}
}
