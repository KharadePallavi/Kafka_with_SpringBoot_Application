package com.example.kafkawithspringboot.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.example.kafkawithspringboot.model.BookJson;

@Service
public class JsonKafkaProducer {

    @Autowired
	private KafkaTemplate<String, BookJson> kafkaTemplate;
	
	
	public void sendMessage(BookJson b) {
		//Message<BookJson> message =MessageBuilder.withPayload(b).setHeader(KafkaHeaders.TOPIC,"javaguides_json").build();
		Message<BookJson> message= MessageBuilder.withPayload(b).setHeader(KafkaHeaders.TOPIC,"javaguides_json").build();
		kafkaTemplate.send(message);
	
	}
	

	
	
}
