package com.example.kafkawithspringboot.config;

import java.util.HashMap;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.example.kafkawithspringboot.model.BookJson;

@Configuration
public class KafkaConsumerConfig {

	
	 public ConsumerFactory<String, BookJson> consumerFactory() {
	        HashMap<String, Object> config = new HashMap<>();
	 
	        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
	        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);

	        return new DefaultKafkaConsumerFactory<>(config);
	    }
	 
	 
	    
	   
}
