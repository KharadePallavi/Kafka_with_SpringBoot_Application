package com.example.kafkawithspringboot.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumer {

	@KafkaListener(topics = "javaguides",groupId = "myGroup")
	public  void listen(String message) {
		System.out.println("The message received="+message);
		
	}
}
