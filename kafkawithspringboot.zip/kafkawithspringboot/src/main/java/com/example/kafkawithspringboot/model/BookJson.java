package com.example.kafkawithspringboot.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@Document(collection ="bookjson")
public class BookJson {

		@Id
		private String id;
		private String name;
		private String price;
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPrice() {
			return price;
		}
		public void setPrice(String price) {
			this.price = price;
		}
		
		public BookJson(String id, String name, String price) {
			super();
			this.id = id;
			this.name = name;
			this.price = price;
		
		}
		public BookJson() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		@Override
		public String toString() {
			return "BookJson [id=" + id + ", name=" + name + ", price=" + price + "]";
		}
		
		
	}


