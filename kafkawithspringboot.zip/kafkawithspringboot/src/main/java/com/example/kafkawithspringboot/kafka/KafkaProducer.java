package com.example.kafkawithspringboot.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.kafkawithspringboot.model.BookJson;


@Service
public class KafkaProducer {

	@Autowired
	private KafkaTemplate<String, BookJson> kafkaTemplate;

	//private static final Logger LOGGER=LoggerFactory.getLogger(KafkaProducer.class);
	
	
	
	public void sendMessage(BookJson message) {
		//LOGGER.info(String.format("Message sent %s", message));
		kafkaTemplate.send("javaguides", message);
	}


}
