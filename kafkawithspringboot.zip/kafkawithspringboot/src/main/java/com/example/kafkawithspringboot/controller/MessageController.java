package com.example.kafkawithspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.kafkawithspringboot.kafka.JsonKafkaProducer;
import com.example.kafkawithspringboot.kafka.KafkaProducer;
import com.example.kafkawithspringboot.model.BookJson;




@RestController
@RequestMapping("/api/v1/kafka")
public class MessageController {
	
	
	@Autowired
	private KafkaProducer kafkaProducer;

	
	@Autowired
	private JsonKafkaProducer jsonKafkaProducer;
	
//	@GetMapping("/publish")
//	public ResponseEntity<String> publish(@RequestParam("message") String message) {
//		kafkaProducer.sendMessage(message);
//		return ResponseEntity.ok("Message sent to consumer");
//	}
	
	//To save the data to the database
	@PostMapping("/publishjson")
	public ResponseEntity<String> publishjson(@RequestBody BookJson book) {
	    jsonKafkaProducer.sendMessage(book);
		return ResponseEntity.ok("Book record sent to the consumer");
	}
	
	//To read the data from the database
//		@PostMapping("/readjson")
//		public ResponseEntity<List<BookJson>> read(){
//			List<BookJson> bookJsons=jsonKafkaProducer
//			return null;
//			
//		  
//			
//		}
	
	

	
}
