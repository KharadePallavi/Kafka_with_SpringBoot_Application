package com.example.kafkawithspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkawithspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
