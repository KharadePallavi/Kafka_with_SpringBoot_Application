package com.example.dockerizedspringbootapplication.service;

import java.util.List;

import com.example.dockerizedspringbootapplication.model.User;

public interface UserService {

	List<User> getAll();

	void addUser(User user);

	User findById(String userId);

	void deleteAlll();

	void deleteById(String id);

	void updateUser(User user);

	

}
