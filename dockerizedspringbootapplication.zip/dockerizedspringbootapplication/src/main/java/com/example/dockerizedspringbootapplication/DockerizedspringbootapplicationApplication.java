package com.example.dockerizedspringbootapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class DockerizedspringbootapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerizedspringbootapplicationApplication.class, args);
	}

}
