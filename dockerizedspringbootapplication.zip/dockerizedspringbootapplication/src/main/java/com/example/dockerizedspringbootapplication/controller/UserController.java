package com.example.dockerizedspringbootapplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dockerizedspringbootapplication.model.User;
import com.example.dockerizedspringbootapplication.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;

	// To add the user into the api
	@PostMapping("/adduser")
	public ResponseEntity<String> addUser(@RequestBody User user) {
		if (user != null) {
			userService.addUser(user);
			return new ResponseEntity<String>("New user successfully added", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Invalid User", HttpStatus.NOT_ACCEPTABLE);
		}
	}

	// To find all the users
	@GetMapping("/getallusers")
	public ResponseEntity<List<User>> getAll() {
		List<User> list = userService.getAll();
		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} else {
			return ResponseEntity.of(Optional.of(list));
		}

	}

	// To update the user information
	@PutMapping("/updateuser")
	public ResponseEntity<String> updateUser(@RequestBody User user){
		if(user.getUserId()!=null) {
        userService.updateUser(user);
		return new ResponseEntity<>("Suceessfully Updated", HttpStatus.OK);
		}else {
	return new ResponseEntity<>("NOT FOUND",HttpStatus.NOT_FOUND);
	}
	}
	

	//To find the user using id
	@GetMapping("/findbyid")
	public ResponseEntity<String> findById(@RequestParam String id){
		User user= userService.findById(id);
		if(user==null) {
			return new ResponseEntity<>("NOT FOUND",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(user.toString()+"\nSuccessfully found",HttpStatus.FOUND);
		
	}

	//To delete the all users
	@DeleteMapping("/deleteall")
	public ResponseEntity<String> deleteAll(){
		userService.deleteAlll();
		return new ResponseEntity<>("Successfully Deleted",HttpStatus.OK);
		
		
	}
	
	
	//To delete the user by id
	@DeleteMapping("/deletebyid")
	public ResponseEntity<String> deleteById(@RequestParam String id){
		User user= userService.findById(id);
       if(user==null) {
	return new ResponseEntity<>("NOT FOUND",HttpStatus.NOT_FOUND);
}
       userService.deleteById(id);
       return new ResponseEntity<>("Deleted", HttpStatus.OK);
	}

}
