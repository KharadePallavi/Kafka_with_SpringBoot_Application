package com.example.dockerizedspringbootapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dockerizedspringbootapplication.dao.UserRepository;
import com.example.dockerizedspringbootapplication.model.User;

@Service
public class UserServiceImpl implements UserService{

	
	
	@Autowired(required = false) 
	private UserRepository userRepository;
	
	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
	
	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		userRepository.save(user);
	}

	@Override
	public User findById(String userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId).get();
	}

	@Override
	public void deleteAlll() {
		// TODO Auto-generated method stub
		userRepository.deleteAll();
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		userRepository.deleteById(id);
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
		User u= userRepository.findById(user.getUserId()).get();
		if(u.getUserId()!=null) {
			u.setUserName(user.getUserName());
			u.setUserAge(user.getUserAge());
			userRepository.save(u);
			
	}

	}
}
