package com.example.demodocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemodockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
