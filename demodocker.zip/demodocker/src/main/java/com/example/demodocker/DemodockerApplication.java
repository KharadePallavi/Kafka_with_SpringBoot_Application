package com.example.demodocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableAutoConfiguration
@SpringBootApplication
public class DemodockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodockerApplication.class, args);
	}

}
