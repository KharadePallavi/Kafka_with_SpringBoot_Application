package com.example.demodocker.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demodocker.dao.UserRepository;
import com.example.demodocker.model.User;

@RestController
@RequestMapping("/users")
public class Controlller {

	
	@Autowired
	private UserRepository userRepository;
	
	
	// To add the user into the api
	@PostMapping("/adduser")
	public ResponseEntity<String> addUser(@RequestBody User user) {
		if (user != null) {
			userRepository.save(user);
			return new ResponseEntity<String>("New user successfully added", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Invalid User", HttpStatus.NOT_ACCEPTABLE);
		}
	}
	
	
	@GetMapping("/getallusers")
	public ResponseEntity<List<User>> getAll() {
		List<User> list = userRepository.findAll();
		if (list.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} else {
			return ResponseEntity.of(Optional.of(list));
		}

	}
}
