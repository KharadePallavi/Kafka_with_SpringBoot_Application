package com.example.kafkarealworldproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkarealworldprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkarealworldprojectApplication.class, args);
	}

}
