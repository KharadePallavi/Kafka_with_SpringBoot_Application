package com.example.kafkarealworldproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkarealworldprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
