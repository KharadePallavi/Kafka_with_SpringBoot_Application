package com.example.kafkaproducer.producer;

import java.net.URI;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.kafkaproducer.handler.EventHandler;
import com.launchdarkly.eventsource.EventSource;

@Service
public class KafkaProducer {

	
	
	private static final Logger LOGGER=LoggerFactory.getLogger(KafkaProducer.class);
	
	
	private KafkaTemplate< String ,String> kafkaTemplate;
	public KafkaProducer(KafkaTemplate<String,String> kafkaTemplate) {
		this.kafkaTemplate= kafkaTemplate;
	}
	
	
	//to read a real time stream data from wikimedia
	
	
	public void sendMessage() throws Exception {
		String topicString="wikimedia_producer";
		EventHandler eventHandler= new EventHandler(kafkaTemplate, topicString);
		String urlString="https://stream.wikimedia.org/v2/stream/recentchange";
		EventSource.Builder builder=new EventSource.Builder(eventHandler, URI.create(urlString));
		EventSource eventSource=builder.build();
		
		
	eventSource.start();
	TimeUnit.MINUTES.sleep(10);
		
	}
}
