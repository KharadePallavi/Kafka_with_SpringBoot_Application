package com.example.kafkaproducer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.kafkaproducer.producer.KafkaProducer;

@SpringBootApplication
public class SpringBootProducerApplication implements CommandLineRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SpringBootProducerApplication.class);

	}
	
	@Autowired
	private KafkaProducer kafkaProducer;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		kafkaProducer.sendMessage();
	}

}
