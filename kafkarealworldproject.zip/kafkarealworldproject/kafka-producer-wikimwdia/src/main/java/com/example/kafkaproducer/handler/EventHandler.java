package com.example.kafkaproducer.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.launchdarkly.eventsource.MessageEvent;

public class EventHandler implements com.launchdarkly.eventsource.EventHandler{

	
	private static final Logger LOGGER=LoggerFactory.getLogger(EventHandler.class);
	
	private KafkaTemplate<String,String> kafkaTemplate;
	private String topicString;
	
	
	public EventHandler(KafkaTemplate<String, String> kafkaTemplate, String topicString) {
		super();
		this.kafkaTemplate = kafkaTemplate;
		this.topicString = topicString;
	}

	@Override
	public void onOpen() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onClosed() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMessage(String event, MessageEvent messageEvent) throws Exception {
		// TODO Auto-generated method stub
	LOGGER.info(String.format("event data -> %s",messageEvent.getData()));	
	kafkaTemplate.send(topicString, messageEvent.getData());
		
	}

	@Override
	public void onComment(String comment) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(Throwable t) {
		// TODO Auto-generated method stub
		
	}

}
