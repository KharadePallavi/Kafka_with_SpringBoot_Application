package com.example.kafkaconsumer.kafkaconsumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.example.kafkaconsumer.JPARepository.WikimediaJPARepository;
import com.example.kafkaconsumer.entity.Wikimedia;

@Service
public class Consumer {
	
	@Autowired
	private WikimediaJPARepository wikimediaJPARepository;
	
	private static final Logger LOGGER= LoggerFactory.getLogger(Consumer.class);
	
	@KafkaListener(topics="wikimedia_producer", groupId="myGroup")
	public void consume(String messageEvent){
		LOGGER.info(String.format("Event message received-> %s", messageEvent));
		Wikimedia wikimedia= new Wikimedia();
		wikimedia.setDataString(messageEvent);
		wikimediaJPARepository.save(wikimedia);
	}
}
